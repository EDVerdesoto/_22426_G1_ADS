package dao;

import model.Estudiante;
import java.util.ArrayList;
import java.util.List;


public class EstudianteDAO {

    private List<Estudiante> estudiantes = new ArrayList<>();

    /*
    * @param Estudiante e: Estudiante a sere agregado a la lista en memoria.
    * */
    public void agregar(Estudiante e) {
        estudiantes.add(e);
    }


    /*
    * Retorno de todos los estudiantes de la lista en memoria.
    * */
    public List<Estudiante> listar() {
        return estudiantes;
    }

    /*
    * @param int id: id del estudiante a ser buscado en la lista en memoria.
    * */
    public Estudiante buscarPorId(int id) {
        for (Estudiante e : estudiantes) {
            if (e.getId() == id) {
                return e;
            }
        }
        return null;
    }

    /*
    * @param Estudiante estudiante: estudiante a ser actualizado.
    * @return Estudiante: Si la edición fue exitosa envía al estudiante actualizado, caso contrario, nulo.
    * */
    public Estudiante editar(Estudiante estudiante){
        for(int i = 0; i < estudiantes.size(); i++){
            if (this.estudiantes.get(i).getId() == estudiante.getId()) {
                this.estudiantes.set(i, estudiante);
                return estudiante;
            }
        }
        return null;
    }

    /*
    * @param int id: id del estudiante a ser eliminado de la lista en memoria.
    * @return Boolean: Determina si la eliminación fue exitosa o no.
    * */
    public Boolean eliminar(int id){
        Estudiante estudianteActual;
        for(int i = 0; i < estudiantes.size(); i++){
            estudianteActual = estudiantes.get(i);
            if (estudianteActual.getId() == id) {
                this.estudiantes.remove(i);
                return true;
            }
        }
        return false;
    }

}
