package view;

import controller.EstudianteController;
import model.Estudiante;
import java.util.List;

import java.util.Scanner;

public class EstudianteView {

    private EstudianteController estudianteController = new EstudianteController();

    public void init(){

        int codSalida = -1;
        Scanner sc = new Scanner(System.in);

        while(codSalida != 0){

            System.out.println("Estudiantes");

            System.out.println("1. Listar Estudiantes");
            System.out.println("2. Agregar Estudiante");
            System.out.println("3. Buscar Estudiante");
            System.out.println("4. Editar Estudiante");
            System.out.println("5. Eliminar Estudiante");
            System.out.println("0. Salir");

            System.out.println("Ingrese una opción: ");

            try{
                codSalida = sc.nextInt();
                sc.nextLine();

                switch (codSalida){
                    case 0:
                        break;
                    case 1:
                        listarEstudiantes();
                        break;
                    case 2:
                        agregarEstudiante();
                        break;
                    case 3:
                        buscarEstudiante();
                        break;
                    case 4:
                        editarEstudiante();
                        break;
                    case 5:
                        eliminarEstudiante();
                        break;
                    default:
                        System.out.println("Opción no disponible.");
                        break;
                }

            }catch (Exception e){
                System.out.println(e.getMessage());
                sc.next();
            }

        }

        sc.close();

    }

    public void listarEstudiantes(){

        List<Estudiante> estudiantes = estudianteController.obtenerTodos();
        for(Estudiante e : estudiantes){
            System.out.println(e.toString());
        }
        System.out.println("");
    }

    public void agregarEstudiante(){
        String respuesta = "";
        int intRespuesta = 0;
        Scanner sc = new Scanner(System.in);


        String nombres, apellidos;
        int edad;

        System.out.println("--Agregar Estudiante--");

        while(!respuesta.matches("/")){

            System.out.println("Ingrese los nombres del estudiante");

            try{
                respuesta = sc.nextLine();

                nombres = respuesta;

                System.out.println("Ingrese los apellidos del estudiante");

                respuesta = sc.nextLine();

                apellidos = respuesta;

                System.out.println("Ingrese la edad del estudiante");

                intRespuesta = sc.nextInt();

                edad = intRespuesta;

                estudianteController.crearEstudiante(apellidos, nombres, edad);

                break;

            }catch (Exception e){
                System.out.println(e.getMessage());
                sc.next();
            }
        }
    }

    public void buscarEstudiante(){
        System.out.println("--Buscar Estudiante--");

        int intRespuesta = 0;
        Scanner sc = new Scanner(System.in);

        Estudiante estudiante;

        System.out.println("--Ingrese el id del estudiante a buscar--");
        try{
            intRespuesta = sc.nextInt();
            estudiante = estudianteController.buscarEstudiante(intRespuesta);
            if(estudiante == null){
                System.out.println("Estudiante no encontrado");
            }else{
                estudiante.toString();
            }

        }catch(Exception e){
            System.out.println(e.getMessage());
            sc.next();
        }
    }

    public void editarEstudiante(){
        System.out.println("--Editar Estudiante--");

        listarEstudiantes();

        String respuesta = "";
        int intRespuesta;
        Scanner sc = new Scanner(System.in);

        String nombres, apellidos;
        int id, edad;

        Estudiante estudiante;

        while(!respuesta.matches("/")){

            System.out.println("\nIngrese el ID del estudiante a editar:");

            try{
                intRespuesta = sc.nextInt();
                id = intRespuesta;

                System.out.println("Ingrese los nuevos nombres del estudiante");

                respuesta = sc.nextLine();

                nombres = respuesta;

                System.out.println("Ingrese los apellidos del estudiante");

                respuesta = sc.nextLine();

                apellidos = respuesta;

                System.out.println("Ingrese la edad del estudiante");

                intRespuesta = sc.nextInt();

                edad = intRespuesta;

                estudianteController.editarEstudiante(apellidos, nombres, edad);

                break;

            }catch (Exception e){
                System.out.println(e.getMessage());
                sc.next();
            }
        }

    }

    public void eliminarEstudiante(){
        System.out.println("--Eliminar Estudiante--");

        int intRespuesta = 0;
        Scanner sc = new Scanner(System.in);

        Boolean eliminado;

        System.out.println("--Ingrese el id del estudiante a buscar--");
        try{
            intRespuesta = sc.nextInt();
            eliminado = estudianteController.eliminarEstudiante(intRespuesta);
            if(!eliminado){
                System.out.println("Estudiante no encontrado");
            }else{
                System.out.println("Estudiante eliminado");
            }

        }catch(Exception e){
            System.out.println(e.getMessage());
            sc.next();
        }

    }

}
