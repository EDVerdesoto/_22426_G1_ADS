package controller;

import dao.EstudianteDAO;
import model.Estudiante;
import java.util.List;

public class EstudianteController {

    private EstudianteDAO dao = new EstudianteDAO();

    public void crearEstudiante(String apellidos, String nombres, int edad) {
        Estudiante e = new Estudiante(apellidos, nombres, edad);

        List<Estudiante> le = obtenerTodos();
        if(!le.isEmpty()){
            e.setId(le.getLast().getId() + 1);
        }
        dao.agregar(e);
    }

    public List<Estudiante> obtenerTodos() {
        return dao.listar();
    }

    public Estudiante buscarEstudiante(int id) {
        return dao.buscarPorId(id);
    }

    public Estudiante editarEstudiante(String apellidos, String nombres, int edad){
        Estudiante e = new Estudiante(apellidos, nombres, edad);
        return dao.editar(e);
    }

    public Boolean eliminarEstudiante(int id){
        return dao.eliminar(id);
    }

}
