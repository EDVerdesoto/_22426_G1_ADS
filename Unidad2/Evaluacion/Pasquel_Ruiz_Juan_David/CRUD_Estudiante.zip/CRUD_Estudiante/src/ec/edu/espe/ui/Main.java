package ec.edu.espe.ui;

import java.util.List;
import java.util.Scanner;
import ec.edu.espe.controller.EstudianteController;
import ec.edu.espe.model.Estudiante;


public class Main {
    //  controlador que manejará la lógica de negocio relacionada con estudiantes.
    private static EstudianteController controller = new EstudianteController();

    //Scanner para leer entradas del usuario desde la consola.
    private static Scanner scanner = new Scanner(System.in);


    public static void main(String[] args) {
        cargarDatosPrueba();

        int opcion; // Variable para almacenar la opción elegida por el usuario.

        // Bucle principal del menú, se repite hasta que el usuario elija la opción 6 (salir).
        do {
            mostrarMenu();
            opcion = leerEntero("Opcion: ");
            procesarOpcion(opcion);
        } while (opcion != 6);

        scanner.close();
    }

    // Muestra el menú principal
    private static void mostrarMenu() {
        System.out.println("\n=== GESTION DE ESTUDIANTES ===");
        System.out.println("1. Agregar    4. Actualizar");
        System.out.println("2. Listar     5. Eliminar");
        System.out.println("3. Buscar     6. Salir");
    }

    // Lee un número entero con validación
    private static int leerEntero(String mensaje) {
        while (true) {
            try {
                System.out.print(mensaje);
                return Integer.parseInt(scanner.nextLine().trim());
            } catch (NumberFormatException e) {
                System.out.println("Error: Ingrese un numero valido");
            }
        }
    }

    // Lee texto no vacío
    private static String leerTexto(String mensaje) {
        while (true) {
            System.out.print(mensaje);
            String texto = scanner.nextLine().trim();
            if (!texto.isEmpty()) return texto;
            System.out.println("Error: Campo obligatorio");
        }
    }

    // Procesa la opción del menú
    private static void procesarOpcion(int opcion) {
        switch (opcion) {
            case 1 -> agregarEstudiante();
            case 2 -> listarEstudiantes();
            case 3 -> buscarEstudiante();
            case 4 -> actualizarEstudiante();
            case 5 -> eliminarEstudiante();
            case 6 -> System.out.println("Saliendo...");
            default -> System.out.println("Opcion invalida");
        }
    }

    // Agrega un nuevo estudiante
    private static void agregarEstudiante() {
        System.out.println("\n--- AGREGAR ESTUDIANTE ---");
        int id = leerEntero("ID: ");
        String apellidos = leerTexto("Apellidos: ");
        String nombres = leerTexto("Nombres: ");
        int edad = leerEntero("Edad: ");

        if (controller.crearEstudiante(id, apellidos, nombres, edad)) {
            System.out.println("Estudiante agregado");
        } else {
            System.out.println("Error: ID ya existe");
        }
    }

    // Lista todos los estudiantes
    private static void listarEstudiantes() {
        System.out.println("\n--- LISTA DE ESTUDIANTES ---");
        List<Estudiante> estudiantes = controller.obtenerTodos();

        if (estudiantes.isEmpty()) {
            System.out.println("No hay estudiantes");
            return;
        }

        System.out.printf("%-5s %-15s %-15s %-5s%n", "ID", "Apellidos", "Nombres", "Edad");
        System.out.println("-".repeat(45));
        estudiantes.forEach(e ->
                System.out.printf("%-5d %-15s %-15s %-5d%n",
                        e.getId(), e.getApellidos(), e.getNombres(), e.getEdad())
        );
    }

    // Busca un estudiante por ID
    private static void buscarEstudiante() {
        System.out.println("\n--- BUSCAR ESTUDIANTE ---");
        int id = leerEntero("ID: ");
        Estudiante estudiante = controller.buscarEstudiante(id);

        if (estudiante != null) {
            mostrarEstudiante(estudiante);
        } else {
            System.out.println("Estudiante no encontrado");
        }
    }

    // Actualiza un estudiante existente
    private static void actualizarEstudiante() {
        System.out.println("\n--- ACTUALIZAR ESTUDIANTE ---");
        int id = leerEntero("ID: ");
        Estudiante estudiante = controller.buscarEstudiante(id);

        if (estudiante == null) {
            System.out.println("Estudiante no encontrado");
            return;
        }

        System.out.println("Datos actuales:");
        mostrarEstudiante(estudiante);

        String apellidos = leerTexto("Nuevos apellidos: ");
        String nombres = leerTexto("Nuevos nombres: ");
        int edad = leerEntero("Nueva edad: ");

        if (controller.actualizarEstudiante(id, apellidos, nombres, edad)) {
            System.out.println("Estudiante actualizado");
        } else {
            System.out.println("Error al actualizar");
        }
    }

    // Elimina un estudiante
    private static void eliminarEstudiante() {
        System.out.println("\n--- ELIMINAR ESTUDIANTE ---");
        int id = leerEntero("ID: ");
        Estudiante estudiante = controller.buscarEstudiante(id);

        if (estudiante == null) {
            System.out.println("Estudiante no encontrado");
            return;
        }

        mostrarEstudiante(estudiante);
        System.out.print("Confirmar eliminacion (S/N): ");
        String confirmacion = scanner.nextLine().trim().toUpperCase();

        if (confirmacion.equals("S")) {
            if (controller.eliminarEstudiante(id)) {
                System.out.println("Estudiante eliminado");
            } else {
                System.out.println("Error al eliminar");
            }
        } else {
            System.out.println("Operacion cancelada");
        }
    }

    // Muestra los datos de un estudiante
    private static void mostrarEstudiante(Estudiante e) {
        System.out.printf("ID: %d, %s %s, Edad: %d%n",
                e.getId(), e.getNombres(), e.getApellidos(), e.getEdad());
    }

    // Carga datos de prueba
    private static void cargarDatosPrueba() {
        controller.crearEstudiante(1, "Benavides", "Ruben", 20);
        controller.crearEstudiante(2, "Conbeña", "Joan", 20);
        controller.crearEstudiante(3, "Verdesoto", "Edison", 15);
    }
}