package ec.edu.espe.dao;

// Importaciones necesarias
import java.util.ArrayList; // arreglo para almacenar estudiantes
import java.util.List;      // lista
import ec.edu.espe.model.Estudiante; // se importa la clase modelo Estudiante

// aqui se simula una base de datos en memoria usando una lista
public class EstudianteDAO {

    // Lista que almacena los objetos Estudiante (simula una base de datos en memoria)
    private List<Estudiante> estudiantes = new ArrayList<>();

    // metodo para agregar un nuevo estudiante a la lista
    public void agregar(Estudiante e) {
        estudiantes.add(e);
    }

    // metodo para obtener la lista completa de estudiantes
    public List<Estudiante> listar() {
        // Se retorna una copia de la lista original para evitar modificarla desde afuera
        return new ArrayList<>(estudiantes);
    }

    // metodo para buscar un estudiante por su ID
    public Estudiante buscarPorId(int id) {
        // Recorre la lista de estudiantes
        for (Estudiante e : estudiantes) {
            // Si encuentra un estudiante con el mismo ID, lo retorna
            if (e.getId() == id) {
                return e;
            }
        }
        // Si no lo encuentra, retorna null
        return null;
    }

    // metodo para actualizar los datos de un estudiante, buscando por ID
    public boolean actualizar(int id, String apellidos, String nombres, int edad) {
        // Busca al estudiante
        Estudiante estudiante = buscarPorId(id);
        if (estudiante != null) {
            // Si existe, actualiza sus datos
            estudiante.setApellidos(apellidos);
            estudiante.setNombres(nombres);
            estudiante.setEdad(edad);
            return true; // Actualización exitosa
        }
        return false; // No se encontró al estudiante
    }

    // metodo para eliminar un estudiante por su ID
    public boolean eliminar(int id) {
        // Busca al estudiante
        Estudiante estudiante = buscarPorId(id);
        if (estudiante != null) {
            // Si existe, lo elimina de la lista
            estudiantes.remove(estudiante);
            return true; // Eliminación exitosa
        }
        return false; // No se encontró al estudiante
    }

    // metodo para verificar si un estudiante con un ID ya existe
    public boolean existeId(int id) {
        // Retorna true si el estudiante existe, false si no
        return buscarPorId(id) != null;
    }
}
