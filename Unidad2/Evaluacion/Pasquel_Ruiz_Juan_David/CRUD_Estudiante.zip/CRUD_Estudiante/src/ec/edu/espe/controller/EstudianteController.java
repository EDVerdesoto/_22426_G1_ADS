package ec.edu.espe.controller;

// Importa las clases necesarias para el controlador.
import java.util.List; // Para poder usar listas
import ec.edu.espe.dao.EstudianteDAO; // DAO que maneja acceso a datos (capa de datos)
import ec.edu.espe.model.Estudiante;  // Modelo de datos que representa a un estudiante

// Clase controladora que actúa como intermediario entre la Vista y el Modelo
public class EstudianteController {

    // Instancia del DAO para acceder a los datos de los estudiantes
    private EstudianteDAO dao = new EstudianteDAO();

    // Metodo para crear un nuevo estudiante
    // Retorna true si se crea correctamente, false si el ID ya existe
    public boolean crearEstudiante(int id, String apellidos, String nombres, int edad) {
        // Verifica si el ID ya existe para evitar duplicados
        if (dao.existeId(id)) {
            return false; // id duplicado, no se puede crear el estudiante
        }

        // Si el ID no existe, se crea una instancia de Estudiante
        Estudiante e = new Estudiante(id, apellidos, nombres, edad);

        // Se agrega el nuevo estudiante usando el DAO
        dao.agregar(e);

        return true; // Estudiante creado con éxito
    }

    // Metodo para obtener la lista completa de estudiantes
    public List<Estudiante> obtenerTodos() {
        return dao.listar(); // Retorna todos los estudiantes almacenados
    }

    // Metodo para buscar un estudiante por su id
    public Estudiante buscarEstudiante(int id) {
        return dao.buscarPorId(id); // Retorna el estudiante encontrado o null si no existe
    }

    // Metodo para actualizar los datos de un estudiante existente
    public boolean actualizarEstudiante(int id, String apellidos, String nombres, int edad) {
        return dao.actualizar(id, apellidos, nombres, edad); // Llama al DAO para hacer la actualización
    }

    // Metodo para eliminar un estudiante por su id
    public boolean eliminarEstudiante(int id) {
        return dao.eliminar(id); // Retorna true si se eliminó correctamente
    }
}
