package ec.edu.espe.model;
// Declaración de la clase pública  Estudiante.
// Representa a un estudiante con atributos básicos como ID, apellidos, nombres y edad.
public class Estudiante {

    // Atributo privado que almacena el identificador único del estudiante.
    private int id;

    // Atributo privado que almacena los apellidos del estudiante.
    private String apellidos;

    // Atributo privado que almacena los nombres del estudiante.
    private String nombres;

    // Atributo privado que almacena la edad del estudiante.
    private int edad;

    // Constructor de la clase. Se usa para crear objetos Estudiante con todos los atributos.
    public Estudiante(int id, String apellidos, String nombres, int edad) {
        this.id = id;
        this.apellidos = apellidos;
        this.nombres = nombres;
        this.edad = edad;
    }

    // ---------------------- MÉTODOS GET Y SET ----------------------

    // metodo getter para obtener el id del estudiante
    public int getId() { return id; }

    //  metodo setter para modificar el id del estudiante
    public void setId(int id) { this.id = id; }

    // metodo getter para obtener los apellidos del estudiante
    public String getApellidos() { return apellidos; }

    // metodo setter para modificar los apellidos del estudiante
    public void setApellidos(String apellidos) { this.apellidos = apellidos; }

    //  metodo getter para obtener los nombres del estudiante
    public String getNombres() { return nombres; }

    // metodo setter para modificar los nombres del estudiante
    public void setNombres(String nombres) { this.nombres = nombres; }

    // metodo getter para obtener la edad del estudiante
    public int getEdad() { return edad; }

    // metodo setter para modificar la edad del estudiante
    public void setEdad(int edad) { this.edad = edad; }

    // metodo sobrescrito de la clase Object. Devuelve una representación en texto del objeto.
    @Override
    public String toString() {
        // Retorna una cadena con el id, nombre completo y edad del estudiante.
        return id + " - " + apellidos + " " + nombres + " - Edad: " + edad;
    }
}