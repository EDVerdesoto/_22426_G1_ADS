package ec.edu.espe.ui;

import ec.edu.espe.controller.EstudianteController;
import ec.edu.espe.model.Estudiante;
import java.util.Scanner;

public class Menu {
    private Scanner scanner;
    private EstudianteController controller;

    public Menu() {
        this.scanner = new Scanner(System.in);
        this.controller = new EstudianteController();
    }

    public void ejecutar() {
        int opcion;

        do {
            mostrarMenu();
            opcion = scanner.nextInt();
            scanner.nextLine(); // Limpiar buffer

            switch (opcion) {
                case 1:
                    crearEstudiante();
                    break;
                case 2:
                    listarEstudiantes();
                    break;
                case 3:
                    buscarEstudiante();
                    break;
                case 4:
                    actualizarEstudiante();
                    break;
                case 5:
                    eliminarEstudiante();
                    break;
                case 6:
                    System.out.println("\n¡Hasta luego!");
                    break;
                default:
                    System.out.println("\nOpción inválida. Intente de nuevo.");
            }
        } while (opcion != 6);

        scanner.close();
    }

    private void mostrarMenu() {
        System.out.println("\n=== SISTEMA DE GESTIÓN DE ESTUDIANTES ===");
        System.out.println("1. Crear estudiante");
        System.out.println("2. Listar todos los estudiantes");
        System.out.println("3. Buscar estudiante por ID");
        System.out.println("4. Actualizar estudiante");
        System.out.println("5. Eliminar estudiante");
        System.out.println("6. Salir");
        System.out.print("Seleccione una opción: ");
    }

    private void crearEstudiante() {
        System.out.println("\n--- CREAR ESTUDIANTE ---");
        System.out.print("Apellidos: ");
        String apellidos = scanner.nextLine();
        System.out.print("Nombres: ");
        String nombres = scanner.nextLine();
        System.out.print("Edad: ");
        int edad = scanner.nextInt();

        int nuevoId = controller.crearEstudiante(apellidos, nombres, edad);
        System.out.println("\nEstudiante creado exitosamente con ID: " + nuevoId);
    }

    private void listarEstudiantes() {
        System.out.println("\n--- LISTA DE ESTUDIANTES ---");
        for (Estudiante estudiante : controller.obtenerTodosEstudiantes()) {
            System.out.println("ID: " + estudiante.getId() +
                    " | Apellidos: " + estudiante.getApellidos() +
                    " | Nombres: " + estudiante.getNombres() +
                    " | Edad: " + estudiante.getEdad());
        }
        if (controller.obtenerTodosEstudiantes().isEmpty()) {
            System.out.println("No hay estudiantes registrados.");
        }
    }

    private void buscarEstudiante() {
        System.out.println("\n--- BUSCAR ESTUDIANTE ---");
        System.out.print("Ingrese el ID del estudiante: ");
        int id = scanner.nextInt();

        Estudiante estudiante = controller.buscarEstudiantePorId(id);
        if (estudiante != null) {
            System.out.println("\nEstudiante encontrado:");
            System.out.println("ID: " + estudiante.getId() +
                    " | Apellidos: " + estudiante.getApellidos() +
                    " | Nombres: " + estudiante.getNombres() +
                    " | Edad: " + estudiante.getEdad());
        } else {
            System.out.println("\nNo se encontró estudiante con ID: " + id);
        }
    }

    private void actualizarEstudiante() {
        System.out.println("\n--- ACTUALIZAR ESTUDIANTE ---");
        System.out.print("ID del estudiante a actualizar: ");
        int id = scanner.nextInt();
        scanner.nextLine();

        if (controller.buscarEstudiantePorId(id) != null) {
            System.out.print("Nuevos apellidos: ");
            String apellidos = scanner.nextLine();
            System.out.print("Nuevos nombres: ");
            String nombres = scanner.nextLine();
            System.out.print("Nueva edad: ");
            int edad = scanner.nextInt();

            boolean actualizado = controller.actualizarEstudiante(id, apellidos, nombres, edad);
            if (actualizado) {
                System.out.println("\nEstudiante actualizado exitosamente.");
            } else {
                System.out.println("\nError al actualizar el estudiante.");
            }
        } else {
            System.out.println("\nNo se encontró estudiante con ID: " + id);
        }
    }

    private void eliminarEstudiante() {
        System.out.println("\n--- ELIMINAR ESTUDIANTE ---");
        System.out.print("ID del estudiante a eliminar: ");
        int id = scanner.nextInt();

        boolean eliminado = controller.eliminarEstudiantePorId(id);
        if (eliminado) {
            System.out.println("\nEstudiante eliminado exitosamente.");
        } else {
            System.out.println("\nNo se encontró estudiante con ID: " + id);
        }
    }
}