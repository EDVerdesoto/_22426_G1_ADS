package ec.edu.espe.dao;

import java.util.ArrayList;
import java.util.List;
import ec.edu.espe.model.Estudiante;

public class EstudianteDAO {
    private List<Estudiante> estudiantes = new ArrayList<>();
    private int proximoId = 1;

    /**
     * Constructor de la clase EstudianteDAO
     * Inicializa la lista de estudiantes con algunos datos predefinidos
     */
    public EstudianteDAO() {
        cargarDatosIniciales();
    }

    /**
     * Carga datos iniciales de estudiantes
     * Este metodo se llama en el constructor para agregar algunos estudiantes predefinidos
     */
    private void cargarDatosIniciales() {
        agregarEstudiante(new Estudiante(obtenerProximoId(), "García", "Juan", 20));
        agregarEstudiante(new Estudiante(obtenerProximoId(), "Martínez", "María", 22));
        agregarEstudiante(new Estudiante(obtenerProximoId(), "López", "Carlos", 21));
        agregarEstudiante(new Estudiante(obtenerProximoId(), "Rodríguez", "Ana", 23));
        agregarEstudiante(new Estudiante(obtenerProximoId(), "Pérez", "Luis", 19));
    }

    /**
     * Obtiene el siguiente ID de estudiante
     * @return el siguiente ID de estudiante
     */
    private int obtenerProximoId() {
        return proximoId++;
    }

    /**
     * Agrega un estudiante a la lista
     * @param estudiante
     * @return true si se agregó correctamente, false si ya existe o es nulo
     */
    public boolean agregarEstudiante(Estudiante estudiante) {
        if (estudiante != null) {
            return estudiantes.add(estudiante);
        }
        return false;
    }

    // Crear con ID autoincremental
    public int agregar(String apellidos, String nombres, int edad) {
        int nuevoId = obtenerProximoId();
        Estudiante estudiante = new Estudiante(nuevoId, apellidos, nombres, edad);
        estudiantes.add(estudiante);
        return nuevoId;
    }

    /**
     * Listar todos los estudiantes
     * @return lista de estudiantes
     */
    public List<Estudiante> listar() {
        return new ArrayList<>(estudiantes);
    }

    /**
     * Busca un estudiante por ID
     * @param id
     * @return estudiante o null si es que no existe
     */
    public Estudiante buscarPorId(int id) {
        for (Estudiante estudiante : estudiantes) {
            if (estudiante.getId() == id) {
                return estudiante;
            }
        }
        return null;
    }

    /**
     * Actualiza un estudiante existente
     * @param estudianteActualizado
     * @return true si se actualizó correctamente, false si no se encontró el estudiante
     */
    public boolean actualizarEstudiante(Estudiante estudianteActualizado) {
        for (int i = 0; i < estudiantes.size(); i++) {
            if (estudiantes.get(i).getId() == estudianteActualizado.getId()) {
                estudiantes.set(i, estudianteActualizado);
                return true;
            }
        }
        return false;
    }

    /**
     * Elimina un estudiante por ID
     * @param id
     * @return true si se eliminó correctamente, false si no se encontró el estudiante
     */
    public boolean eliminarEstudiantePorId(int id) {
        return estudiantes.removeIf(estudiante -> estudiante.getId() == id);
    }
}