package ec.edu.espe.command;

import java.util.Stack;

/**
 * Invocador de comandos; mantiene un historial para deshacer
 */
public class CommandInvoker {

    private final Stack<Command> historial = new Stack<>();

    public void ejecutarComando(Command comando) {
        comando.execute();
        historial.push(comando);
    }

    public void deshacer() {
        if (!historial.isEmpty()) {
            historial.pop().undo();
        }
    }

    public boolean puedeDeshacer() {
        return !historial.isEmpty();
    }
}
