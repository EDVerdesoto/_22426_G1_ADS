package ec.edu.espe.adapter;

import ec.edu.espe.modelo.Estudiante;
import ec.edu.espe.repositorio.EstudianteRepositorio;
import java.util.List;

/**
 * Adaptador para el repositorio en memoria existente
 */
public class EstudianteRepositorioAdapter implements IEstudianteDataSource {

    private final EstudianteRepositorio repositorio;

    public EstudianteRepositorioAdapter(EstudianteRepositorio repositorio) {
        this.repositorio = repositorio;
    }

    @Override public void guardar(Estudiante estudiante)   { repositorio.agregar(estudiante); }
    @Override public void actualizar(Estudiante estudiante){ repositorio.actualizar(estudiante); }
    @Override public void eliminar(int id)                 { repositorio.eliminar(id); }
    @Override public List<Estudiante> obtenerTodos()       { return repositorio.obtenerTodos(); }
    @Override public Estudiante buscarPorId(int id)        { return repositorio.buscarPorId(id); }
}
