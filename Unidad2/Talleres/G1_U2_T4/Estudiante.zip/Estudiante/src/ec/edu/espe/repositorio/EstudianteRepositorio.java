package ec.edu.espe.repositorio;

import java.util.ArrayList;
import java.util.List;

import ec.edu.espe.modelo.Estudiante;

/**
 * Clase que actúa como repositorio (acceso a datos) de estudiantes.
 * Simula el almacenamiento en memoria de los datos de estudiantes.
 */
public class EstudianteRepositorio {
    private List<Estudiante> estudiantes = new ArrayList<>();

    /**
     * Agregar un nuevo estudiante al repositorio
     * @param estudiante estudiante a agregar
     */
    public void agregar(Estudiante estudiante) {
        estudiantes.add(estudiante);
    }

    /**
     * Actualizar los datos de un estudiante existente
     * @param estudiante estudiante con los nuevos datos
     */
    public void actualizar(Estudiante estudiante) {
        for (int i = 0; i < estudiantes.size(); i++) {
            if (estudiantes.get(i).getId() == estudiante.getId()) {
                estudiantes.set(i, estudiante);
                break;
            }
        }
    }

    /**
     * Eliminar un estudiante del repositorio por id
     * @param id identificador único del estudiante a eliminar
     */
    public void eliminar(int id) {
        estudiantes.removeIf(e -> e.getId() == id);
    }

    /**
     * Obtener todos los estudiantes registrados
     * @return List<Estduiante> lista de estudiantes
     */
    public List<Estudiante> obtenerTodos() {
        return new ArrayList<>(estudiantes);
    }

    /**
     * Buscar un estudiante por id
     * @param id identificador único
     * @return estudiante encontrado o null si no existe
     */
    public Estudiante buscarPorId(int id) {
        for (Estudiante e : estudiantes) {
            if (e.getId() == id) return e;
        }
        return null;
    }
}