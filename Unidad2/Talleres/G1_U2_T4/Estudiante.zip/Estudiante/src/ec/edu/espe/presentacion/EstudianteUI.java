package ec.edu.espe.presentacion;

import ec.edu.espe.modelo.Estudiante;
import ec.edu.espe.servicio.EstudianteServicio;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;

/**
 * GUI para el CRUD de Estudiantes con soporte de:
 *   • Deshacer (CommandInvoker)
 *   • Cambio de fuente de datos (Adapter)  ← opcional
 */
public class EstudianteUI extends JFrame {

    /* --------------  Controles -------------- */
    private JTextField txtId, txtNombre, txtEdad;
    private JButton btnAgregar, btnActualizar, btnEliminar,
            btnMostrar, btnDeshacer;
    private JTable tabla;
    private DefaultTableModel modeloTabla;
    private JComboBox<EstudianteServicio.TipoFuente> cboFuente;   // opcional

    /* --------------  Servicio --------------- */
    private final EstudianteServicio servicio = new EstudianteServicio();

    /* -------------- Constructor ------------- */
    public EstudianteUI() {

        /*—–» Config. ventana */
        setTitle("Gestión de Estudiantes");
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setSize(600, 420);
        setLocationRelativeTo(null);

        /*—–» Formulario */
        JPanel panelForm = new JPanel(new GridBagLayout());
        panelForm.setBorder(BorderFactory.createTitledBorder("Datos del Estudiante"));
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(6, 6, 6, 6);
        gbc.anchor = GridBagConstraints.EAST;

        JLabel lblId     = new JLabel("ID:");
        JLabel lblNombre = new JLabel("Nombre:");
        JLabel lblEdad   = new JLabel("Edad:");

        txtId     = new JTextField(15);
        txtNombre = new JTextField(15);
        txtEdad   = new JTextField(15);

        gbc.gridx = 0; gbc.gridy = 0; panelForm.add(lblId, gbc);
        gbc.gridx = 1;                panelForm.add(txtId, gbc);
        gbc.gridx = 0; gbc.gridy = 1; panelForm.add(lblNombre, gbc);
        gbc.gridx = 1;                panelForm.add(txtNombre, gbc);
        gbc.gridx = 0; gbc.gridy = 2; panelForm.add(lblEdad, gbc);
        gbc.gridx = 1;                panelForm.add(txtEdad, gbc);

        /*—–» Botones  */
        JPanel panelBotones = new JPanel(new FlowLayout(FlowLayout.CENTER, 10, 5));
        btnAgregar   = new JButton("Agregar");
        btnActualizar= new JButton("Actualizar");
        btnEliminar  = new JButton("Eliminar");
        btnMostrar   = new JButton("Mostrar Todo");
        btnDeshacer  = new JButton("Deshacer");
        btnDeshacer.setEnabled(false);              // deshabilitado al inicio

        /*—–» Selector de fuente de datos (opcional) */
        cboFuente = new JComboBox<>(EstudianteServicio.TipoFuente.values());
        cboFuente.setToolTipText("Cambiar fuente de datos");

        panelBotones.add(btnAgregar);
        panelBotones.add(btnActualizar);
        panelBotones.add(btnEliminar);
        panelBotones.add(btnMostrar);
        panelBotones.add(btnDeshacer);
        panelBotones.add(cboFuente);

        /*—–» Tabla */
        modeloTabla = new DefaultTableModel(new Object[]{"ID", "Nombre", "Edad"}, 0) {
            public boolean isCellEditable(int row, int column) { return false; }
        };
        tabla = new JTable(modeloTabla);
        tabla.setRowHeight(25);
        tabla.getTableHeader().setFont(tabla.getTableHeader().getFont().deriveFont(Font.BOLD));
        JScrollPane scrollTabla = new JScrollPane(tabla);

        /*—–» Layout principal */
        JPanel panelSuperior = new JPanel(new BorderLayout(5, 5));
        panelSuperior.add(panelForm, BorderLayout.CENTER);
        panelSuperior.add(panelBotones, BorderLayout.SOUTH);

        add(panelSuperior, BorderLayout.NORTH);
        add(scrollTabla,   BorderLayout.CENTER);

        /* --------------  Listeners ---------------- */

        btnAgregar.addActionListener(e -> {
            try {
                int id      = Integer.parseInt(txtId.getText().trim());
                String nom  = txtNombre.getText().trim();
                int edad    = Integer.parseInt(txtEdad.getText().trim());
                servicio.agregarEstudiante(id, nom, edad);
                mostrarTodos();
                limpiarCampos();
                actualizarEstadoBotones();
            } catch (Exception ex) {
                mostrarError("Datos inválidos. Verifica los campos.");
            }
        });

        btnActualizar.addActionListener(e -> {
            try {
                int id      = Integer.parseInt(txtId.getText().trim());
                String nom  = txtNombre.getText().trim();
                int edad    = Integer.parseInt(txtEdad.getText().trim());
                servicio.actualizarEstudiante(id, nom, edad);
                mostrarTodos();
                limpiarCampos();
                actualizarEstadoBotones();
            } catch (Exception ex) {
                mostrarError("Datos inválidos. Verifica los campos.");
            }
        });

        btnEliminar.addActionListener(e -> {
            try {
                int id = Integer.parseInt(txtId.getText().trim());
                servicio.eliminarEstudiante(id);
                mostrarTodos();
                limpiarCampos();
                actualizarEstadoBotones();
            } catch (Exception ex) {
                mostrarError("Ingresa un ID válido.");
            }
        });

        btnMostrar.addActionListener(e -> mostrarTodos());

        btnDeshacer.addActionListener(e -> {
            servicio.deshacer();
            mostrarTodos();
            actualizarEstadoBotones();
        });

        /*—–» Cambio de fuente de datos (opcional) */
        cboFuente.addActionListener(e -> {
            EstudianteServicio.TipoFuente tipo =
                    (EstudianteServicio.TipoFuente) cboFuente.getSelectedItem();
            servicio.cambiarFuenteDatos(tipo);
            mostrarTodos();
        });

        /*—–» Click sobre la tabla para cargar campos */
        tabla.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                int fila = tabla.getSelectedRow();
                if (fila != -1) {
                    txtId.setText(modeloTabla.getValueAt(fila, 0).toString());
                    txtNombre.setText(modeloTabla.getValueAt(fila, 1).toString());
                    txtEdad.setText(modeloTabla.getValueAt(fila, 2).toString());
                }
            }
        });
    }

    /* --------------  Utilidades ---------------- */

    private void mostrarTodos() {
        modeloTabla.setRowCount(0);
        for (Estudiante est : servicio.obtenerTodos()) {
            modeloTabla.addRow(new Object[]{est.getId(), est.getNombre(), est.getEdad()});
        }
    }

    private void limpiarCampos() {
        txtId.setText(""); txtNombre.setText(""); txtEdad.setText("");
    }

    private void actualizarEstadoBotones() {
        btnDeshacer.setEnabled(servicio.puedeDeshacer());
    }

    private void mostrarError(String msg) {
        JOptionPane.showMessageDialog(this, msg, "Error", JOptionPane.ERROR_MESSAGE);
    }

    /* --------------  Arranque ---------------- */
    public static void mostrar() {
        try {
            for (UIManager.LookAndFeelInfo info : UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (Exception ignored) {}
        SwingUtilities.invokeLater(() -> new EstudianteUI().setVisible(true));
    }
}
