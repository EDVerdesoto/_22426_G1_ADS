package ec.edu.espe.adapter;

import ec.edu.espe.modelo.Estudiante;
import java.util.List;

/**
 * Interfaz que define las operaciones de una fuente de datos de estudiantes
 */
public interface IEstudianteDataSource {
    void guardar(Estudiante estudiante);
    void actualizar(Estudiante estudiante);
    void eliminar(int id);
    List<Estudiante> obtenerTodos();
    Estudiante buscarPorId(int id);
}
