package ec.edu.espe;

import ec.edu.espe.presentacion.EstudianteUI;

public class Main {
    public static void main(String[] args) {
        EstudianteUI.mostrar();
    }
}
