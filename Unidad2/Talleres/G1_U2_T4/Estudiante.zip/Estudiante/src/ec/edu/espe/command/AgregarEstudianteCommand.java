package ec.edu.espe.command;

import ec.edu.espe.adapter.IEstudianteDataSource;
import ec.edu.espe.modelo.Estudiante;
import ec.edu.espe.repositorio.EstudianteRepositorio;

/**
 * Comando para agregar un estudiante
 */
public class AgregarEstudianteCommand implements Command {

    private final IEstudianteDataSource dataSource;
    private final Estudiante estudiante;

    public AgregarEstudianteCommand(IEstudianteDataSource dataSource, Estudiante estudiante) {
        this.dataSource = dataSource;
        this.estudiante  = estudiante;
    }

    @Override
    public void execute() {
        dataSource.guardar(estudiante);
    }

    @Override
    public void undo() {
        dataSource.eliminar(estudiante.getId());
    }
}
