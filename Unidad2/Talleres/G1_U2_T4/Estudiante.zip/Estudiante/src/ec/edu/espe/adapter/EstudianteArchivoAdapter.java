package ec.edu.espe.adapter;

import ec.edu.espe.modelo.Estudiante;

import java.io.*;
import java.util.ArrayList;
import java.util.List;

/**
 * Adaptador para persistencia en archivos
 */
public class EstudianteArchivoAdapter implements IEstudianteDataSource {

    private static final String ARCHIVO = "estudiantes.dat";
    private List<Estudiante> estudiantes;

    public EstudianteArchivoAdapter() {
        cargarDatos();
    }

    /* Métodos CRUD */

    @Override public void guardar(Estudiante estudiante) {
        estudiantes.add(estudiante);
        guardarDatos();
    }

    @Override public void actualizar(Estudiante estudiante) {
        for (int i = 0; i < estudiantes.size(); i++) {
            if (estudiantes.get(i).getId() == estudiante.getId()) {
                estudiantes.set(i, estudiante);
                guardarDatos();
                break;
            }
        }
    }

    @Override public void eliminar(int id) {
        estudiantes.removeIf(e -> e.getId() == id);
        guardarDatos();
    }

    @Override public List<Estudiante> obtenerTodos() {
        return new ArrayList<>(estudiantes);
    }

    @Override public Estudiante buscarPorId(int id) {
        return estudiantes.stream()
                .filter(e -> e.getId() == id)
                .findFirst()
                .orElse(null);
    }

    /* Utilidades de serialización */

    @SuppressWarnings("unchecked")
    private void cargarDatos() {
        try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream(ARCHIVO))) {
            estudiantes = (List<Estudiante>) ois.readObject();
        } catch (Exception e) {
            estudiantes = new ArrayList<>();
        }
    }

    private void guardarDatos() {
        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(ARCHIVO))) {
            oos.writeObject(estudiantes);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
