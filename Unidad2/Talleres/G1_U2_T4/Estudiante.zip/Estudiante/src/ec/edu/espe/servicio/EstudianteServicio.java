package ec.edu.espe.servicio;

import java.util.List;
import ec.edu.espe.adapter.IEstudianteDataSource;
import ec.edu.espe.adapter.EstudianteRepositorioAdapter;
import ec.edu.espe.adapter.EstudianteArchivoAdapter;
import ec.edu.espe.command.CommandInvoker;
import ec.edu.espe.command.AgregarEstudianteCommand;
import ec.edu.espe.command.ActualizarEstudianteCommand;
import ec.edu.espe.command.EliminarEstudianteCommand;
import ec.edu.espe.modelo.Estudiante;
import ec.edu.espe.repositorio.EstudianteRepositorio;

/**
 * Servicio que orquesta las operaciones CRUD de Estudiante
 * utilizando los patrones Command y Adapter.
 * <p>
 * Gestiona la fuente de datos (memoria o archivo),
 * delega comandos para las operaciones de agregar,
 * actualizar y eliminar, y permite deshacer acciones.
 */
public class EstudianteServicio {

    private final EstudianteRepositorio repositorio;
    private IEstudianteDataSource dataSource;
    private final CommandInvoker invoker;

    /**
     * Inicializa el servicio con el repositorio en memoria
     * y configura el invocador de comandos.
     */
    public EstudianteServicio() {
        this.repositorio = new EstudianteRepositorio();
        this.dataSource  = new EstudianteRepositorioAdapter(repositorio);
        this.invoker     = new CommandInvoker();
    }

    /**
     * Cambia la fuente de datos entre memoria y archivo.
     *
     * @param tipo Tipo de almacenamiento a utilizar ({@code MEMORIA} o {@code ARCHIVO}).
     */
    public void cambiarFuenteDatos(TipoFuente tipo) {
        switch (tipo) {
            case MEMORIA:
                this.dataSource = new EstudianteRepositorioAdapter(repositorio);
                break;
            case ARCHIVO:
                this.dataSource = new EstudianteArchivoAdapter();
                break;
        }
    }

    /**
     * Agrega un nuevo estudiante y registra la operación en el historial.
     *
     * @param id     Identificador único del estudiante.
     * @param nombre Nombre completo del estudiante.
     * @param edad   Edad del estudiante.
     */
    public void agregarEstudiante(int id, String nombre, int edad) {
        Estudiante est = new Estudiante(id, nombre, edad);
        invoker.ejecutarComando(new AgregarEstudianteCommand(dataSource, est));
    }

    /**
     * Actualiza los datos de un estudiante existente y guarda la acción.
     *
     * @param id     Identificador único del estudiante a actualizar.
     * @param nombre Nuevo nombre del estudiante.
     * @param edad   Nueva edad del estudiante.
     */
    public void actualizarEstudiante(int id, String nombre, int edad) {
        Estudiante est = new Estudiante(id, nombre, edad);
        invoker.ejecutarComando(new ActualizarEstudianteCommand(dataSource, est));
    }

    /**
     * Elimina un estudiante por su identificador y registra la operación.
     *
     * @param id Identificador único del estudiante a eliminar.
     */
    public void eliminarEstudiante(int id) {
        invoker.ejecutarComando(new EliminarEstudianteCommand(dataSource, id));
    }

    /**
     * Obtiene todos los estudiantes de la fuente de datos actual.
     *
     * @return Lista de estudiantes.
     */
    public List<Estudiante> obtenerTodos() {
        return dataSource.obtenerTodos();
    }

    /**
     * Deshace la última operación ejecutada (agregar, actualizar o eliminar).
     */
    public void deshacer() {
        invoker.deshacer();
    }

    /**
     * Indica si hay operaciones en el historial que se puedan deshacer.
     *
     * @return {@code true} si existe al menos una acción deshabilitante; {@code false} en caso contrario.
     */
    public boolean puedeDeshacer() {
        return invoker.puedeDeshacer();
    }

    /**
     * Tipos de fuentes de datos disponibles para la persistencia.
     */
    public enum TipoFuente {
        /** Usa el repositorio en memoria. */
        MEMORIA,
        /** Usa la persistencia en archivo. */
        ARCHIVO
    }
}
