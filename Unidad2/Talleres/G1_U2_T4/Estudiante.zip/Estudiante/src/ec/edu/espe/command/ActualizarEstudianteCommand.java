package ec.edu.espe.command;

import ec.edu.espe.adapter.IEstudianteDataSource;
import ec.edu.espe.modelo.Estudiante;
import ec.edu.espe.repositorio.EstudianteRepositorio;

/**
 * Comando para actualizar un estudiante
 */
public class ActualizarEstudianteCommand implements Command {

    private final IEstudianteDataSource dataSource;
    private final Estudiante estudianteNuevo;
    private final Estudiante estudianteAnterior;

    public ActualizarEstudianteCommand(IEstudianteDataSource dataSource, Estudiante estudianteNuevo) {
        this.dataSource        = dataSource;
        this.estudianteNuevo    = estudianteNuevo;
        this.estudianteAnterior = dataSource.buscarPorId(estudianteNuevo.getId());
    }

    @Override
    public void execute() {
        dataSource.actualizar(estudianteNuevo);
    }

    @Override
    public void undo() {
        if (estudianteAnterior != null) {
            dataSource.actualizar(estudianteAnterior);
        }
    }
}
