package ec.edu.espe.command;

/**
 * Interfaz Command que define el método execute para ejecutar comandos
 */
public interface Command {
    void execute();
    void undo();   // Para deshacer la operación
}
