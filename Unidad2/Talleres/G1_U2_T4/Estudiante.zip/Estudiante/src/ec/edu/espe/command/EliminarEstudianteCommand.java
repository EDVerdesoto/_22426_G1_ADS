package ec.edu.espe.command;

import ec.edu.espe.adapter.IEstudianteDataSource;
import ec.edu.espe.modelo.Estudiante;
import ec.edu.espe.repositorio.EstudianteRepositorio;

/**
 * Comando para eliminar un estudiante
 */
public class EliminarEstudianteCommand implements Command {

    private final IEstudianteDataSource dataSource;
    private final int id;
    private Estudiante estudianteEliminado;

    public EliminarEstudianteCommand(IEstudianteDataSource dataSource, int id) {
        this.dataSource = dataSource;
        this.id= id;
    }

    @Override
    public void execute() {
        estudianteEliminado = dataSource.buscarPorId(id); // respaldo
        dataSource.eliminar(id);
    }

    @Override
    public void undo() {
        if (estudianteEliminado != null) {
            dataSource.guardar(estudianteEliminado);
        }
    }
}
