package ec.edu.espe.modelo;

public class Estudiante {
    private int id;
    private String nombre;
    private int edad;

    /**
     * Constructor del estudiante
     * @param id identificador único del estudiante
     * @param nombre nombre del estudiante
     * @param edad edad del estudiante
     */
    public Estudiante(int id, String nombre, int edad) {
        this.id = id;
        this.nombre = nombre;
        this.edad = edad;
    }

    /**
     * Obtener el id del estudiante
     * @return id
     */
    public int getId() { return id; }
    /**
     * Establecer el id del estudiante
     * @param id identificador único
     */
    public void setId(int id) { this.id = id; }

    /**
     * Obtener el nombre del estudiante
     * @return nombre
     */
    public String getNombre() { return nombre; }
    /**
     * Establecer el nombre del estudiante
     * @param nombre nombre
     */
    public void setNombre(String nombre) { this.nombre = nombre; }

    /**
     * Obtener la edad del estudiante
     * @return edad
     */
    public int getEdad() { return edad; }
    /**
     * Establecer la edad del estudiante
     * @param edad edad
     */
    public void setEdad(int edad) { this.edad = edad; }
}
