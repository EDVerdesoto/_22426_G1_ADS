package ec.edu.espe.servicio;

import java.util.List;

import ec.edu.espe.repositorio.EstudianteRepositorio;
import ec.edu.espe.modelo.Estudiante;

/**
 * Clase de servicio que implementa la lógica de negocio para estudiantes.
 * Realiza validaciones y orquesta las operaciones antes de acceder a la capa de datos.
 */
public class EstudianteServicio {
    private EstudianteRepositorio repositorio = new EstudianteRepositorio();

    /**
     * Agregar estudiante con validación de datos
     * @param id identificador único
     * @param nombre nombre
     * @param edad edad
     */
    public void agregarEstudiante(int id, String nombre, int edad) {
        // Validaciones simples, aquí se puede ampliar con reglas de negocio
        Estudiante estudiante = new Estudiante(id, nombre, edad);
        repositorio.agregar(estudiante);
    }

    /**
     * Actualizar los datos de un estudiante
     * @param id identificador único
     * @param nombre nombre
     * @param edad edad
     */
    public void actualizarEstudiante(int id, String nombre, int edad) {
        Estudiante estudiante = new Estudiante(id, nombre, edad);
        repositorio.actualizar(estudiante);
    }

    /**
     * Eliminar un estudiante
     * @param id identificador único
     */
    public void eliminarEstudiante(int id) {
        repositorio.eliminar(id);
    }

    /**
     * Obtener todos los estudiantes
     * @return lista de estudiantes
     */
    public List<Estudiante> obtenerTodos() {
        return repositorio.obtenerTodos();
    }
}