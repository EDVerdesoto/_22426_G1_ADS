package ec.edu.espe.presentacion;

import ec.edu.espe.servicio.EstudianteServicio;
import ec.edu.espe.modelo.Estudiante;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;

/**
 * Clase que contiene toda la interfaz gráfica para el CRUD de estudiantes.
 */
public class EstudianteUI extends JFrame {
    private JTextField txtId, txtNombre, txtEdad;
    private JButton btnAgregar, btnActualizar, btnEliminar, btnMostrar;
    private JTable tabla;
    private DefaultTableModel modeloTabla;
    private EstudianteServicio servicio = new EstudianteServicio();

    /**
     * Constructor de la GUI.
     */
    public EstudianteUI() {
        setTitle("Gestión de Estudiantes");
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setSize(550, 400);
        setLocationRelativeTo(null);

        JPanel panelForm = new JPanel(new GridBagLayout());
        panelForm.setBorder(BorderFactory.createTitledBorder("Datos del Estudiante"));
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(6, 6, 6, 6);

        JLabel lblId = new JLabel("ID:");
        JLabel lblNombre = new JLabel("Nombre:");
        JLabel lblEdad = new JLabel("Edad:");

        txtId = new JTextField(15);
        txtNombre = new JTextField(15);
        txtEdad = new JTextField(15);

        gbc.gridx = 0; gbc.gridy = 0; gbc.anchor = GridBagConstraints.EAST;
        panelForm.add(lblId, gbc);
        gbc.gridx = 1; gbc.anchor = GridBagConstraints.WEST;
        panelForm.add(txtId, gbc);

        gbc.gridx = 0; gbc.gridy = 1; gbc.anchor = GridBagConstraints.EAST;
        panelForm.add(lblNombre, gbc);
        gbc.gridx = 1; gbc.anchor = GridBagConstraints.WEST;
        panelForm.add(txtNombre, gbc);

        gbc.gridx = 0; gbc.gridy = 2; gbc.anchor = GridBagConstraints.EAST;
        panelForm.add(lblEdad, gbc);
        gbc.gridx = 1; gbc.anchor = GridBagConstraints.WEST;
        panelForm.add(txtEdad, gbc);

        JPanel panelBotones = new JPanel(new FlowLayout(FlowLayout.CENTER, 10, 5));
        btnAgregar = new JButton("Agregar");
        btnActualizar = new JButton("Actualizar");
        btnEliminar = new JButton("Eliminar");
        btnMostrar = new JButton("Mostrar Todo");
        panelBotones.add(btnAgregar);
        panelBotones.add(btnActualizar);
        panelBotones.add(btnEliminar);
        panelBotones.add(btnMostrar);

        modeloTabla = new DefaultTableModel(new Object[]{"ID", "Nombre", "Edad"}, 0) {
            public boolean isCellEditable(int row, int column) { return false; }
        };
        tabla = new JTable(modeloTabla);
        tabla.setRowHeight(25);
        tabla.getTableHeader().setFont(tabla.getTableHeader().getFont().deriveFont(Font.BOLD));
        JScrollPane scrollTabla = new JScrollPane(tabla);

        JPanel panelSuperior = new JPanel(new BorderLayout(5,5));
        panelSuperior.add(panelForm, BorderLayout.CENTER);
        panelSuperior.add(panelBotones, BorderLayout.SOUTH);

        add(panelSuperior, BorderLayout.NORTH);
        add(scrollTabla, BorderLayout.CENTER);

        btnAgregar.addActionListener(e -> {
            try {
                int id = Integer.parseInt(txtId.getText().trim());
                String nombre = txtNombre.getText().trim();
                int edad = Integer.parseInt(txtEdad.getText().trim());
                servicio.agregarEstudiante(id, nombre, edad);
                mostrarTodos();
                limpiarCampos();
            } catch (Exception ex) {
                mostrarError("Datos inválidos. Verifica los campos.");
            }
        });

        btnActualizar.addActionListener(e -> {
            try {
                int id = Integer.parseInt(txtId.getText().trim());
                String nombre = txtNombre.getText().trim();
                int edad = Integer.parseInt(txtEdad.getText().trim());
                servicio.actualizarEstudiante(id, nombre, edad);
                mostrarTodos();
                limpiarCampos();
            } catch (Exception ex) {
                mostrarError("Datos inválidos. Verifica los campos.");
            }
        });

        btnEliminar.addActionListener(e -> {
            try {
                int id = Integer.parseInt(txtId.getText().trim());
                servicio.eliminarEstudiante(id);
                mostrarTodos();
                limpiarCampos();
            } catch (Exception ex) {
                mostrarError("Ingresa un ID válido.");
            }
        });

        btnMostrar.addActionListener(e -> mostrarTodos());

        tabla.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                int fila = tabla.getSelectedRow();
                if (fila != -1) {
                    txtId.setText(modeloTabla.getValueAt(fila, 0).toString());
                    txtNombre.setText(modeloTabla.getValueAt(fila, 1).toString());
                    txtEdad.setText(modeloTabla.getValueAt(fila, 2).toString());
                }
            }
        });
    }

    private void mostrarTodos() {
        modeloTabla.setRowCount(0);
        for (Estudiante est : servicio.obtenerTodos()) {
            modeloTabla.addRow(new Object[]{est.getId(), est.getNombre(), est.getEdad()});
        }
    }

    private void limpiarCampos() {
        txtId.setText("");
        txtNombre.setText("");
        txtEdad.setText("");
    }

    private void mostrarError(String msg) {
        JOptionPane.showMessageDialog(this, msg, "Error", JOptionPane.ERROR_MESSAGE);
    }

    /**
     * Llama a esta función para mostrar la GUI.
     */
    public static void mostrar() {
        try {
            for (UIManager.LookAndFeelInfo info : UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (Exception ignored) {}
        SwingUtilities.invokeLater(() -> new EstudianteUI().setVisible(true));
    }
}
